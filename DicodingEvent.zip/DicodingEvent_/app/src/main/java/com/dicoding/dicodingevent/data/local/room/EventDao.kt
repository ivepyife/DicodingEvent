package com.dicoding.dicodingevent.data.local.room

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.dicoding.dicodingevent.data.local.entity.EventEntity

@Dao
interface EventDao {
    @Query("SELECT * FROM event where status = 1 OR status = 0")
    fun getEvent(): LiveData<List<EventEntity>>

    @Query("SELECT * FROM event where status = 1")
    fun getUpcomingEvent(): LiveData<List<EventEntity>>

    @Query("SELECT * FROM event where status = 0")
    fun getFinishedEvent(): LiveData<List<EventEntity>>

    @Query("SELECT * FROM event where favorite = 1")
    fun getFavoriteEvent(): LiveData<List<EventEntity>>

    @Query("SELECT * FROM event WHERE name LIKE :query AND status = 1")
    fun searchUpcomingEvents(query: String): LiveData<List<EventEntity>>

    @Query("SELECT * FROM event WHERE name LIKE :query AND status = 0")
    fun searchFinishedEvents(query: String): LiveData<List<EventEntity>>

    @Query("SELECT * FROM event WHERE id = :eventId LIMIT 1")
    suspend fun getEventById(eventId: Int): EventEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: List<EventEntity>)

    @Update
    suspend fun updateEvent(event: EventEntity)

    @Query("DELETE FROM event WHERE favorite = 0")
    suspend fun deleteAll()

    @Query("DELETE FROM event WHERE status = 1 OR status = 0")
    suspend fun deleteEvents()

    @Query("DELETE FROM event WHERE status = 1")
    suspend fun deleteUpcomingEvents()

    @Query("DELETE FROM event WHERE status = 0")
    suspend fun deleteFinishedEvents()

    @Query("SELECT EXISTS(SELECT * FROM event WHERE id = :eventId AND favorite = 1)")
    suspend fun isEventFavorite(eventId: Int): Boolean

    @Query("SELECT EXISTS(SELECT * FROM event WHERE id = :eventId AND (status = 1 OR status = 0))")
    suspend fun isEventActive(eventId: Int): Boolean
}